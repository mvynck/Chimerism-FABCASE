# number of samples impact script

library(poibin)
library(ggplot2)
library(cowplot)

convertMAF <- function(MAF){
  return(min(MAF, 0.5)-max(MAF-0.5, 0))
}

MAFvec <- function(MAF, reps, n){
  rbinom(reps, n, MAF)/n
}

cdfVec <- function(use, probs, nmark){
  1-ppoibin(nmark, probs[1:use])
}


MAFtoProb <- function(MAFvec, donrec = c("sib", "mud", "pc"), type=c("i", "i-ii")){
  if(donrec == "mud"){
    if(type=="i"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+2*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "sib"){
    if(type=="i"){
      probs <- 1/2*(3*MAFvec^2*(1-MAFvec )^2+2*(MAFvec*(1-MAFvec )^3)+2*MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 1/2*(5*MAFvec^2*(1-MAFvec )^2+4*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "pc"){
    if(type=="i"){
      probs <- 2*MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )
    }
    if(type=="i-ii"){
      probs <- 2*(2*MAFvec^2*(1-MAFvec )^2+ (MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
  }
  return(probs)
}

getCIwidth <- function(maf.est, B, b, rel, type){
  d <- matrix(0, nrow = B, ncol = length(maf.est))
  for(iter in 1:B){
    d[iter,] <- sapply(1:length(maf.est), cdfVec, MAFtoProb(b[iter,], donrec=rel, type=type), 3)
  }
  quantiles <- c(0.025, 0.975)
  upper <- vector("numeric", length(maf.est))
  lower <- vector("numeric", length(maf.est))
  for(mark in 1:length(maf.est)){
    upper[mark] <- sort(d[, mark])[quantiles[2]*(B+1)]
    lower[mark] <- sort(d[, mark])[quantiles[1]*(B+1)]
  }
  return(upper-lower)
}

nsamp <- c(10, 20, 50, 100, 200)*2 # multiply by two, two alleles/sample
nmarkers <- 1:24
# empirical MAFs
MAF1 <- c(0.4059633, 0.4357798, 0.3302752, 0.4128440, 0.4564220, 0.4839450, 0.3990826, 0.4403670, 0.4747706,
0.3348624, 0.4311927, 0.4449541, 0.3922018, 0.3876147, 0.4128440, 0.3876147, 0.4380734, 0.4770642,
0.4633028, 0.4885321, 0.4380734, 0.3394495, 0.4220183, 0.4380734)
# random MAFs
set.seed(54321)
MAF2 <- runif(24, 0.3, 0.5)
# perfect MAFs
MAF3 <- rep(0.5, 24)
ci.width1mud <- matrix(0, nrow=length(nsamp), ncol = 24)
ci.width1sib <- matrix(0, nrow=length(nsamp), ncol = 24)
ci.width2mud <- matrix(0, nrow=length(nsamp), ncol = 24)
ci.width2sib <- matrix(0, nrow=length(nsamp), ncol = 24)
ci.width3mud <- matrix(0, nrow=length(nsamp), ncol = 24)
ci.width3sib <- matrix(0, nrow=length(nsamp), ncol = 24)
for(sampsize in 1:length(nsamp)){
  AF.dep <- nsamp[sampsize]
  # use more bootstraps here to gain smoother CI width curves
  B = 9999
  
  set.seed(123)
  #set1
  maf.est <- MAF1
  b <- matrix(MAFvec(maf.est, B*length(maf.est), AF.dep), nrow = B, byrow = TRUE)  
  ci.width1mud[sampsize,] <- getCIwidth(maf.est, B, b, rel="mud", "i")
  ci.width1sib[sampsize,] <- getCIwidth(maf.est, B, b, rel="sib", "i")
  #set2
  maf.est <- MAF2
  b <- matrix(MAFvec(maf.est, B*length(maf.est), AF.dep), nrow = B, byrow = TRUE)  
  ci.width2mud[sampsize,] <- getCIwidth(maf.est, B, b, rel="mud", "i")
  ci.width2sib[sampsize,] <- getCIwidth(maf.est, B, b, rel="sib", "i")
  #set3
  maf.est <- MAF3
  b <- matrix(MAFvec(maf.est, B*length(maf.est), AF.dep), nrow = B, byrow = TRUE)  
  ci.width3mud[sampsize,] <- getCIwidth(maf.est, B, b, rel="mud", "i")
  ci.width3sib[sampsize,] <- getCIwidth(maf.est, B, b, rel="sib", "i")
}
mud1 <- data.frame(width=c(ci.width1mud),size=rep(1:24, each = length(nsamp)), samples=rep(nsamp, length(MAF1)))
mud1$samples <- as.factor(mud1$samples/2)
sib1 <- data.frame(width=c(ci.width1sib),size=rep(1:24, each = length(nsamp)), samples=rep(nsamp, length(MAF1)))
sib1$samples <- as.factor(sib1$samples/2)


mud1p <- ggplot(mud1, aes(x=size,y=width, group=samples))+
          geom_line(aes(color=samples))+
          theme_minimal()+
          ylab("95% CI width")+
          xlab("Number of markers included")+
  ylim(0, 0.15)+
  theme(legend.position = "none")

sib1p <- ggplot(sib1, aes(x=size,y=width, group=samples))+
  geom_line(aes(color=samples))+
  theme_minimal()+
  ylab("95% CI width")+
  xlab("Number of markers included")+
  ylim(0, 0.15)+
  theme(legend.position = "none")

plot_grid(mud1p, sib1p, ncol = 2, labels = c("a","b"))

mud2 <- data.frame(width=c(ci.width2mud),size=rep(1:24, each = length(nsamp)), samples=rep(nsamp, length(MAF1)))
mud2$samples <- as.factor(mud2$samples/2)
sib2 <- data.frame(width=c(ci.width2sib),size=rep(1:24, each = length(nsamp)), samples=rep(nsamp, length(MAF1)))
sib2$samples <- as.factor(sib2$samples/2)
mud2p <- ggplot(mud2, aes(x=size,y=width, group=samples))+
  geom_line(aes(color=samples))+
  theme_minimal()+
  ylab("95% CI width")+
  xlab("Number of markers included")+
  ylim(0, 0.15)+
  theme(legend.position = "none")

sib2p <- ggplot(sib2, aes(x=size,y=width, group=samples))+
  geom_line(aes(color=samples))+
  theme_minimal()+
  ylab("95% CI width")+
  xlab("Number of markers included")+
  ylim(0, 0.15)+
  theme(legend.position = "none")+
  theme(legend.position = "none")

plot_grid(mud2p, sib2p, ncol = 2, labels = c("a","b"))

mud3 <- data.frame(width=c(ci.width3mud),size=rep(1:24, each = length(nsamp)), samples=rep(nsamp, length(MAF1)))
mud3$samples <- as.factor(mud3$samples/2)
sib3 <- data.frame(width=c(ci.width3sib),size=rep(1:24, each = length(nsamp)), samples=rep(nsamp, length(MAF1)))
sib3$samples <- as.factor(sib3$samples/2)
mud3p <- ggplot(mud3, aes(x=size,y=width, group=samples))+
  geom_line(aes(color=samples))+
  theme_minimal()+
  ylab("95% CI width")+
  xlab("Number of markers included")+
  ylim(0, 0.15)+
  theme(legend.position = "none")

sib3p <- ggplot(sib3, aes(x=size,y=width, group=samples))+
  geom_line(aes(color=samples))+
  theme_minimal(base_size = 10)+
  ylab("95% CI width")+
  xlab("Number of markers included")+
  ylim(0, 0.15)
legendp <- cowplot::get_legend(sib3p)
sib3p <- ggplot(sib3, aes(x=size,y=width, group=samples))+
  geom_line(aes(color=samples))+
  theme_minimal()+
  ylab("95% CI width")+
  xlab("Number of markers included")+
  ylim(0, 0.15)+
  theme(legend.position = "none")


plot_grid(mud3p, sib3p, ncol = 2, labels = c("a","b"))

plot_grid(mud1p, mud2p, mud3p, legendp, sib1p, sib2p, sib3p, ncol=4, rel_widths = c(4,4,4,1),
          labels=c("a", "b", "c", "", "d", "e", "f"))
