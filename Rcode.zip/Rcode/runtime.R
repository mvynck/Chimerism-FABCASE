nrep <- 100
set.seed(123)
pop.freq.mat <- matrix(runif(50*nrep, 0.3, 0.5), nrow = nrep)

#######################################
# MCsim time
#######################################

MCstart <- Sys.time()
for(rep in 1:nrep){
  cat(rep," - ")
# initialize matrices to store simulation results
res.related.devyser <- matrix(-1, nrow = nsim, ncol = 50)
res.unrelated.devyser <- matrix(-1, nrow = nsim, ncol = 50)
res.pc.devyser <- matrix(-1, nrow = nsim, ncol = 50)
res.related.devyser.homo <- matrix(-1, nrow = nsim, ncol = 50)
res.unrelated.devyser.homo <- matrix(-1, nrow = nsim, ncol = 50)
res.pc.devyser.homo <- matrix(-1, nrow = nsim, ncol = 50)
res.related.devyser.allinf <- matrix(-1, nrow = nsim, ncol = 50)
res.unrelated.devyser.allinf <- matrix(-1, nrow = nsim, ncol = 50)
res.pc.devyser.allinf <- matrix(-1, nrow = nsim, ncol = 50)

pop.freq <- pop.freq.mat[rep,]
nsim <- 10000
for(sim in 1:nsim){
  for(marker in 1:50){
    # generate parental and offspring genotypes
    p1 <- sample(c("A", "B"), size = 2, replace = TRUE, prob = c(pop.freq[marker], 1-pop.freq[marker]))
    p2 <- sample(c("A", "B"), size = 2, replace = TRUE, prob = c(pop.freq[marker], 1-pop.freq[marker]))
    o1 <- c(sample(p1, size = 1), sample(p2, size = 1))
    o2 <- c(sample(p1, size = 1), sample(p2, size = 1))
    sum(sort(p1) != sort(o2)) == 2 || (sum(sort(p1) == c("A", "B")) == 2 && (sum(o2 == c("A", "A")) == 2 || sum(o2 == c("B", "B")) == 2 ))
    
    # true/false informative
    if(sum(sort(o1) != sort(o2)) == 2 || (sum(sort(o1) == c("A", "B")) == 2 && (sum(o2 == c("A", "A")) == 2 || sum(o2 == c("B", "B")) == 2 ))){
      res.related.devyser[sim, marker] <- 1
    } else {
      res.related.devyser[sim, marker] <- 0
    }
    if(sum(sort(p1) != sort(p2)) == 2 || (sum(sort(p1) == c("A", "B")) == 2 && (sum(p2 == c("A", "A")) == 2 || sum(p2 == c("B", "B")) == 2 ))){
      res.unrelated.devyser[sim, marker] <- 1
    } else {
      res.unrelated.devyser[sim, marker] <- 0
    }
    if(sum(sort(p1) != sort(o2)) == 2 || (sum(sort(p1) == c("A", "B")) == 2 && (sum(o2 == c("A", "A")) == 2 || sum(o2 == c("B", "B")) == 2 ))){
      res.pc.devyser[sim, marker] <- 1
    } else {
      res.pc.devyser[sim, marker] <- 0
    }
    
    # true/false informative homozygous
    if(sum(sort(o1) != sort(o2)) == 2){
      res.related.devyser.homo[sim, marker] <- 1
    } else {
      res.related.devyser.homo[sim, marker] <- 0
    }
    if(sum(sort(p1) != sort(p2)) == 2){
      res.unrelated.devyser.homo[sim, marker] <- 1
    } else {
      res.unrelated.devyser.homo[sim, marker] <- 0
    }
    if(sum(sort(p1) != sort(o2)) == 2){
      res.pc.devyser.homo[sim, marker] <- 1
    } else {
      res.pc.devyser.homo[sim, marker] <- 0
    }
    
    # true/false informative + potentially informative
    if(sum(sort(o1) != sort(o2)) == 2 || (sum(sort(o1) == c("A", "B")) == 2 && (sum(o2 == c("A", "A")) == 2 || sum(o2 == c("B", "B")) == 2 )) || (sum(sort(o2) == c("A", "B")) == 2 && (sum(o1 == c("A", "A")) == 2 || sum(o1 == c("B", "B")) == 2 ))){
      res.related.devyser.allinf[sim, marker] <- 1
    } else {
      res.related.devyser.allinf[sim, marker] <- 0
    }
    if(sum(sort(p1) != sort(p2)) == 2|| (sum(sort(p1) == c("A", "B")) == 2 && (sum(p2 == c("A", "A")) == 2 || sum(p2 == c("B", "B")) == 2 )) || (sum(sort(p2) == c("A", "B")) == 2 && (sum(p1 == c("A", "A")) == 2 || sum(p1 == c("B", "B")) == 2 ))){
      res.unrelated.devyser.allinf[sim, marker] <- 1
    } else {
      res.unrelated.devyser.allinf[sim, marker] <- 0
    }
    if(sum(sort(p1) != sort(o2)) == 2|| (sum(sort(p1) == c("A", "B")) == 2 && (sum(o2 == c("A", "A")) == 2 || sum(o2 == c("B", "B")) == 2 )) || (sum(sort(o2) == c("A", "B")) == 2 && (sum(p1 == c("A", "A")) == 2 || sum(p1 == c("B", "B")) == 2 ))){
      res.pc.devyser.allinf[sim, marker] <- 1
    } else {
      res.pc.devyser.allinf[sim, marker] <- 0
    }
  }
}

# generate average informative values across 
#  simulations, as function of number of markers
means.vec.related.devyser <- vector("numeric", 50-2)
means.vec.unrelated.devyser <- vector("numeric", 50-2)
means.vec.pc.devyser <- vector("numeric", 50-2)
means.vec.related.devyser.homo <- vector("numeric", 50-2)
means.vec.unrelated.devyser.homo <- vector("numeric", 50-2)
means.vec.pc.devyser.homo <- vector("numeric", 50-2)
means.vec.related.devyser.allinf <- vector("numeric", 50-2)
means.vec.unrelated.devyser.allinf <- vector("numeric", 50-2)
means.vec.pc.devyser.allinf <- vector("numeric", 50-2)
for(calcmean in 3:50){
  means.vec.related.devyser[calcmean-2] <- mean(rowSums(res.related.devyser[,1:calcmean]) >= 3)
  means.vec.unrelated.devyser[calcmean-2] <- mean(rowSums(res.unrelated.devyser[,1:calcmean]) >= 3)
  means.vec.pc.devyser[calcmean-2] <- mean(rowSums(res.pc.devyser[,1:calcmean]) >= 3)
  means.vec.related.devyser.homo[calcmean-2] <- mean(rowSums(res.related.devyser.homo[,1:calcmean]) >= 3)
  means.vec.unrelated.devyser.homo[calcmean-2] <- mean(rowSums(res.unrelated.devyser.homo[,1:calcmean]) >= 3)
  means.vec.pc.devyser.homo[calcmean-2] <- mean(rowSums(res.pc.devyser.homo[,1:calcmean]) >= 3)
  means.vec.related.devyser.allinf[calcmean-2] <- mean(rowSums(res.related.devyser.allinf[,1:calcmean]) >= 3)
  means.vec.unrelated.devyser.allinf[calcmean-2] <- mean(rowSums(res.unrelated.devyser.allinf[,1:calcmean]) >= 3)
  means.vec.pc.devyser.allinf[calcmean-2] <- mean(rowSums(res.pc.devyser.allinf[,1:calcmean]) >= 3)
}
}
(MCelapsed <- Sys.time()-MCstart)

#######################################
# FABCASE time
#######################################

FABstart <- Sys.time()


MAFtoProb <- function(MAFvec, donrec = c("sib", "mud", "pc"), type=c("i", "i-ii")){
  if(donrec == "mud"){
    if(type=="i"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+2*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "sib"){
    if(type=="i"){
      probs <- 1/2*(3*MAFvec^2*(1-MAFvec )^2+2*(MAFvec*(1-MAFvec )^3)+2*MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 1/2*(5*MAFvec^2*(1-MAFvec )^2+4*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "pc"){
    if(type=="i"){
      probs <- 2*MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )
    }
    if(type=="i-ii"){
      probs <- 2*(2*MAFvec^2*(1-MAFvec )^2+ (MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
  }
  return(probs)
}

library(poibin)
for(rep in 1:nrep){
  cat(rep," - ")
  pop.freq <- pop.freq.mat[rep,]
  (estimateMUD <- max(sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="mud", type="i"), 3)))
  (estimateSIB <- max(sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="sib", type="i"), 3)))
  (estimatePC <- max(sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="pc", type="i"), 3)))
  (estimateMUDii <- max(sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="mud", type="i-ii"), 3)))
  (estimateSIBii <- max(sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="sib", type="i-ii"), 3)))
  (estimatePCii <- max(sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="pc", type="i-ii"), 3)))
}

(FABelapsed <- Sys.time()-FABstart)
