library(poibin)

dat <- read.csv("~/Google Drive/Mijn Drive/Werk-UGent/2022/FABCAD/Data/ExampleMAF.csv", sep=";")
colnames(dat)[1] <- c("variant")
load("~/Google Drive/Mijn Drive/Werk-UGent/2022/FABCAD/Data/results.RData")

convertMAF <- function(MAF){
  return(min(MAF, 0.5)-max(MAF-0.5, 0))
}

MAFvec <- function(MAF, reps, n){
  rbinom(reps, n, MAF)/n
}

cdfVec <- function(use, probs, nmark){
  1-ppoibin(nmark, probs[1:use])
}



MAFtoProb <- function(MAFvec, donrec = c("sib", "mud", "pc"), type=c("i", "i-ii")){
  if(donrec == "mud"){
    if(type=="i"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+2*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "sib"){
    if(type=="i"){
      probs <- 1/2*(3*MAFvec^2*(1-MAFvec )^2+2*(MAFvec*(1-MAFvec )^3)+2*MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 1/2*(5*MAFvec^2*(1-MAFvec )^2+4*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "pc"){
    if(type=="i"){
      probs <- 2*MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )
    }
    if(type=="i-ii"){
      probs <- 2*(2*MAFvec^2*(1-MAFvec )^2+ (MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
  }
  return(probs)
}


dat <- dat[-which(dat$AF == "-"),]
dat <- dat[-which(dat$variant == ""),]
dat <- dat[!duplicated(dat$variant),]
dat$AF <- sapply(as.numeric(dat$AF), convertMAF)
dat$AFR_AF <- sapply(as.numeric(dat$AFR_AF), convertMAF)
dat$AMR_AF <- sapply(as.numeric(dat$AMR_AF), convertMAF)
dat$EAS_AF <- sapply(as.numeric(dat$EAS_AF), convertMAF)
dat$EUR_AF <- sapply(as.numeric(dat$EUR_AF), convertMAF)
dat$SAS_AF <- sapply(as.numeric(dat$SAS_AF), convertMAF)
boxplot(dat[,2:7])
pop.df <- data.frame(MAF = c(dat$AFR_AF, dat$AMR_AF, dat$EAS_AF, dat$EUR_AF, dat$SAS_AF),
                     Population = c(rep("African", nrow(dat)),
                                    rep("American", nrow(dat)),
                                    rep("East-Asian", nrow(dat)),
                                    rep("European", nrow(dat)),
                                    rep("South-Asian", nrow(dat))))
a=ggplot(pop.df, aes(x=Population, y=MAF))+
  geom_boxplot()+
  geom_jitter(aes(color="grey"), width=0.25)+
  theme_minimal()+
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 45, vjust = 1, hjust=1))+
  xlab("")
  

# random marker selection
set.seed(1)
dat <- dat[sample(1:nrow(dat)),]

AF.dep <- 500*2
B = 999
ll <- matrix(0, nrow = 5, ncol = nrow(dat))
ul <- matrix(0, nrow = 5, ncol = nrow(dat))
pe <- matrix(0, nrow = 5, ncol = nrow(dat))


ll.sib <- matrix(0, nrow = 5, ncol = nrow(dat))
ul.sib <- matrix(0, nrow = 5, ncol = nrow(dat))
pe.sib <- matrix(0, nrow = 5, ncol = nrow(dat))

for(pop in 1:5){
  maf.est <- dat[,2+pop]
  b <- matrix(MAFvec(maf.est, B*length(maf.est), AF.dep), nrow = B, byrow = TRUE)

  # MUD
  pe[pop,] <- estimate <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 2)
  d <- matrix(0, nrow = B, ncol = length(maf.est))
  for(iter in 1:B){
    d[iter,] <- sapply(1:length(maf.est), cdfVec, MAFtoProb(b[iter,], donrec="mud", type="i"), 2)
  }
  quantiles <- c(0.025, 0.975)
  upper <- vector("numeric", length(maf.est))
  lower <- vector("numeric", length(maf.est))
  for(mark in 1:length(maf.est)){
    upper[mark] <- sort(d[, mark])[quantiles[2]*(B+1)]
    lower[mark] <- sort(d[, mark])[quantiles[1]*(B+1)]
  }
  (upper.final <- upper)
  (lower.final <- lower)
  
  # if lower than 0 or higher than 1, replace
  lower.final <- sapply(lower.final, max, 0)
  upper.final <- sapply(upper.final, min, 1)
  ll[pop,] <- lower.final
  ul[pop,] <- upper.final
  
  # SIBLING
  pe.sib[pop,] <- estimate <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, "sib", "i"), 2)
  d <- matrix(0, nrow = B, ncol = length(maf.est))
  for(iter in 1:B){
    d[iter,] <- sapply(1:length(maf.est), cdfVec, MAFtoProb(b[iter,], "sib", "i"), 2)
  }
  quantiles <- c(0.025, 0.975)
  upper <- vector("numeric", length(maf.est))
  lower <- vector("numeric", length(maf.est))
  for(mark in 1:length(maf.est)){
    upper[mark] <- sort(d[, mark])[quantiles[2]*(B+1)]
    lower[mark] <- sort(d[, mark])[quantiles[1]*(B+1)]
  }
  (upper.final <- lower)
  (lower.final <- upper)
  
  # if lower than 0 or higher than 1, replace
  lower.final <- sapply(lower.final, max, 0)
  upper.final <- sapply(upper.final, min, 1)
 
  ll.sib[pop,] <- lower.final
  ul.sib[pop,] <- upper.final
}

res.pop <- data.frame(Informativity = c(pe, ll, ul,
                                        pe.sib, ll.sib, ul.sib),
                      Population = c(rep(c("African", "American", "East-Asian", "European", "South-Asian"), 48 * 6)),
                      Relatedness = c(rep("Unrelated", 48 * 5 * 3),
                                      rep("Sibling", 48* 5.* 3)),
                      Type = rep(c("pe", "ll", "ul", "pe", "ll", "ul"), each = 48*5),
                      Markers = rep(rep(1:48, each = 5), 6))
res.pop.mud.pe <- res.pop[res.pop$Relatedness=="Sibling",]
res.pop.mud.pe <- res.pop.mud.pe[res.pop.mud.pe$Type=="ll",]
b=ggplot(res.pop.mud.pe, aes(x = Markers, y = Informativity, color = Population))+
  geom_line()+
  theme_minimal()+
  ylim(0.95, 1)+
  xlim(25, 48)+
  theme(legend.position = "top", legend.)

plot_grid(a, b, labels=c("a", "b"), rel_widths = c(2, 6))

### compare ethnicities



AF.dep <- 1000
B = 999
maf.est <- dat$AF[order(dat$AF)]
estimateAF <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 3)
estimateAFsib <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 3)

maf.est <- dat$AFR_AF[order(dat$AFR_AF)]
estimateAFR <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 3)
estimateAFRsib <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 3)

maf.est <- dat$AMR_AF[order(dat$AMR_AF)]
estimateAMR <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 3)
estimateAMRsib <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 3)

maf.est <- dat$EAS_AF[order(dat$EAS_AF)]
estimateEAS <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 3)
estimateEASsib <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 3)

maf.est <- dat$EUR_AF[order(dat$EUR_AF)]
estimateEUR <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 3)
estimateEURsib <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 3)

maf.est <- dat$SAS_AF[order(dat$SAS_AF)]
estimateSAS <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 3)
estimateSASsib <- sapply(1:length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 3)


plot(1:length(maf.est), estimateAF, type = "l", ylab="Fraction of transplants with at least 3 informative markers",xlab="Number of markers")
lines(1:length(maf.est), estimateAFR, lty = 1, col="orange")
lines(1:length(maf.est), estimateAMR, lty = 1, col="blue")
lines(1:length(maf.est), estimateEAS, lty = 1, col="grey")
lines(1:length(maf.est), estimateEUR, lty = 1, col="darkgreen")
lines(1:length(maf.est), estimateSAS, lty = 1, col="purple")
lines(1:length(maf.est), estimateAFsib, lty = 3, col="black")
lines(1:length(maf.est), estimateAFRsib, lty = 3, col="orange")
lines(1:length(maf.est), estimateAMRsib, lty = 3, col="blue")
lines(1:length(maf.est), estimateEASsib, lty = 3, col="grey")
lines(1:length(maf.est), estimateEURsib, lty = 3, col="darkgreen")
lines(1:length(maf.est), estimateSASsib, lty = 3, col="purple")


#######################################
#
# Assess impact of the number of
#  samples used
#
#######################################

#number of samples
nsamp <- c(10, 20, 50, 100, 200)
# get FABCASE quantiles
library(poibin)
mudMAF <- MAFtoProb(pop.freq, "mud", "i")
sibMAF <- MAFtoProb(pop.freq, "sib", "i")
pcMAF <- MAFtoProb(pop.freq, "pc", "i")

mudMAFii <- MAFtoProb(pop.freq, "mud", "i-ii")
sibMAFii <- MAFtoProb(pop.freq, "sib", "i-ii")
pcMAFii <- MAFtoProb(pop.freq, "pc", "i-ii")


AF.dep <- 10
B = 999
maf.est <- pop.freq
b <- matrix(MAFvec(maf.est, B*length(maf.est), AF.dep), nrow = B, byrow = TRUE)
#boxplot(b, xlab = "Marker ID", ylab = "Parametric bootstrap MAFs")
head(b)

d <- matrix(0, nrow = B, ncol = length(maf.est))
for(iter in 1:B){
  d[iter,] <- sapply(1:length(maf.est), cdfVec, MAFtoProb(b[iter,], donrec="mud", type="i"), 3)
}
quantiles <- c(0.025, 0.975)
upper <- vector("numeric", length(maf.est))
lower <- vector("numeric", length(maf.est))
for(mark in 1:length(maf.est)){
  upper[mark] <- sort(d[, mark])[quantiles[2]*(B+1)]
  lower[mark] <- sort(d[, mark])[quantiles[1]*(B+1)]
}
(upper.final <- estimate - lower)
(lower.final <- estimate - upper)
(upper.final <- upper)
(lower.final <- lower)

# if lower than 0 or higher than 1, replace
lower.final <- sapply(lower.final, max, 0)
upper.final <- sapply(upper.final, min, 1)
plot(1:length(maf.est), estimate, type = "l",ylim=c(0,1.0))
lines(1:length(maf.est), upper.final, lty = 3)
lines(1:length(maf.est), lower.final, lty = 3)

# note: for small samples and MAFs close to 0.5,
#. the MAF is underestimated
ns <- 10
test <- rbinom(10000,ns,0.5)/ns
test[test>0.5] <- 0.5-(test[test>0.5]-0.5)
mean(test)
