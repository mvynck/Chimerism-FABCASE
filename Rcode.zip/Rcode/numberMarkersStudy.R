setwd("~/Google Drive/Mijn Drive/Werk-UGent/2022/FABCAD/Rcode")

MAFtoProb <- function(MAFvec, donrec = c("sib", "mud", "pc"), type=c("i", "i-ii")){
  if(donrec == "mud"){
    if(type=="i"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+2*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "sib"){
    if(type=="i"){
      probs <- 1/2*(3*MAFvec^2*(1-MAFvec )^2+2*(MAFvec*(1-MAFvec )^3)+2*MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 1/2*(5*MAFvec^2*(1-MAFvec )^2+4*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "pc"){
    if(type=="i"){
      probs <- 2*MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )
    }
    if(type=="i-ii"){
      probs <- 2*(2*MAFvec^2*(1-MAFvec )^2+ (MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
  }
  return(probs)
}

#######################################
#
# Load libraries
#
#######################################
library(ggplot2)
library(scales)
library(cowplot)
library(reshape2)

#######################################
#
# Define general parameters
#
#######################################

#number of simulations per setting
nsim <- 10000

# maximum number of markers in assay
max.markers <- 100

set.seed(1)
#######################################
#
# MAFs from Devyser assay
# Diploid (i.e. no X/Y)
#
#######################################
source("simDevyser.R")



#######################################
#
# Compare theoretical and empirical
#   results
# Graphical: density plots
# Statistical: Poisson regression
#
#######################################

# compare theoretical vs experimental
MarkerFrequency <- read.csv("../Data/NumberInformativeMarkers.csv", sep = ";")
MarkerFrequency$MUD[MarkerFrequency$MUD=="n"] <- "Related"
MarkerFrequency$MUD[MarkerFrequency$MUD=="y"] <- "Unrelated"
MarkerFrequency$MUD[MarkerFrequency$MUD=="parent-child"] <- "Parent-child"
MarkerFrequency <- MarkerFrequency[complete.cases(MarkerFrequency),]
# get FABCASE quantiles
library(poibin)
mudMAF <- MAFtoProb(MAFvec = pop.freq, donrec = "mud", type = "i")
sibMAF <- MAFtoProb(pop.freq, "sib", "i")
pcMAF <- MAFtoProb(pop.freq, "pc", "i")

mudMAFii <- MAFtoProb(pop.freq, "mud", "i-ii")
sibMAFii <- MAFtoProb(pop.freq, "sib", "i-ii")
pcMAFii <- MAFtoProb(pop.freq, "pc", "i-ii")

set.seed(1)
dataForDensityInf <- list("Sibling Empirical"=MarkerFrequency$Informative.markers[MarkerFrequency$MUD=="Related"],
                          "Unrelated Empirical"=MarkerFrequency$Informative.markers[MarkerFrequency$MUD=="Unrelated"],
                       "Sibling MCsim"=sample(rowSums(res.related.devyser),100),
                       "Unrelated MCsim"=sample(rowSums(res.unrelated.devyser),100),
                       "Sibling FABCASE"=rpoibin(1e2,sibMAF),
                       "Unrelated FABCASE"=rpoibin(1e2,mudMAF))
dataForDensityAll <- list("Rel Emp All"=MarkerFrequency$Informative.markers[MarkerFrequency$MUD=="Related"]+MarkerFrequency$Potentially.informative.markers[MarkerFrequency$MUD=="Related"][1:100],
                          "Unrel Emp All"=MarkerFrequency$Informative.markers[MarkerFrequency$MUD=="Unrelated"]+MarkerFrequency$Potentially.informative.markers[MarkerFrequency$MUD=="Unrelated"][1:100],
                       "Rel MCsim All"=sample(rowSums(res.related.devyser.allinf),100),
                       "Unrel MCsim All"=sample(rowSums(res.unrelated.devyser.allinf),100),
                       "Rel FABCASE All"=rpoibin(1e2,sibMAFii),
                       "Unrel FABCASE All"=rpoibin(1e2,mudMAFii))
dataForDensityInf <- melt(dataForDensityInf)
dataForDensityAll <- melt(dataForDensityAll)

grey_palette <- c("#003049", "#D62828", "#F77F00", "#FCBF49", "#007F00", "#00BF49")
gInf <- ggplot(dataForDensityInf,
               aes(x = value, y=L1, fill=L1))+
  geom_violin(adjust=3,
              trim = FALSE,
              color = NA,
              alpha = 0.6)+
  geom_boxplot(
               alpha = 0.5)+
  theme_minimal()+
  xlab("")+
  theme(legend.position = "none",
        legend.title = element_blank(),
        axis.text.y = element_blank())+
  ylab("")+
  xlim(0,24)+
  scale_fill_manual(values = grey_palette)

gAll <- ggplot(dataForDensityAll,
               aes(x = value, y=L1, fill=L1))+
  geom_violin(adjust=3,
              trim = FALSE,
              color = NA,
              alpha = 0.6)+
  geom_boxplot(
               alpha = 0.5)+
  theme_minimal()+
  xlab("Number of informative markers")+
  theme(legend.position = "none",
        legend.title = element_blank(),
        axis.text.y = element_blank())+
  ylab("")+
  xlim(0,24)+
  scale_fill_manual(values = grey_palette)
legend <- get_legend(
  gInf + 
    theme(legend.position = "top")
)
plots <- plot_grid(
  legend,
  gInf + theme(legend.position="none"),
  gAll + theme(legend.position="none"),
  labels = c("", "A", "B"),
  nrow = 3, rel_heights = c(.2, 1, 1)
)

pdf("../Figures/empthe.pdf", height = 6)
plots
dev.off()

# compare theoretical to empirical using poisson regression
#   on the observed frequencies of different types of markers

dataForDensityInfPoisson <- dataForDensityInf
dataForDensityInfPoisson$Related <- substr(dataForDensityInfPoisson$L1, 1, 3) == "Sib"
dataForDensityInfPoisson$MCsim <- unlist(strsplit(dataForDensityInfPoisson$L1, " "))[seq(2, nrow(dataForDensityInfPoisson)*2, 2)] == "MCsim"
dataForDensityInfPoisson$FABCASE <- unlist(strsplit(dataForDensityInfPoisson$L1, " "))[seq(2, nrow(dataForDensityInfPoisson)*2, 2)] == "FABCASE"
InfReg <- glm(value ~ Related + MCsim + FABCASE, data = dataForDensityInfPoisson, family = "poisson")
InfRegRel <- glm(value ~ Related, data = dataForDensityInfPoisson, family = "poisson")
summary(InfReg)
library(lmtest)
lrtest(InfReg, InfRegRel)

dataForDensityAllPoisson <- dataForDensityAll
dataForDensityAllPoisson$Related <- substr(dataForDensityAllPoisson$L1, 1, 3) == "Rel"
dataForDensityAllPoisson$MCsim <- unlist(strsplit(dataForDensityAllPoisson$L1, " "))[seq(2, nrow(dataForDensityAllPoisson)*3, 3)] == "MCsim"
dataForDensityAllPoisson$FABCASE <- unlist(strsplit(dataForDensityAllPoisson$L1, " "))[seq(2, nrow(dataForDensityAllPoisson)*3, 3)] == "FABCASE"
AllReg <- glm(value ~ Related + MCsim +FABCASE, data = dataForDensityAllPoisson, family = "poisson")
AllRegRel <- glm(value ~ Related, data = dataForDensityAllPoisson, family = "poisson")
summary(AllReg)
lrtest(AllReg, AllRegRel)

library(AER)
dispersiontest(InfReg,trafo=1)
dispersiontest(AllReg,trafo=1)



# save all results
save.image("../Data/results.RData")
