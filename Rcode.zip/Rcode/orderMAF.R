
MAFtoProb <- function(MAFvec, donrec = c("sib", "mud", "pc"), type=c("i", "i-ii")){
  if(donrec == "mud"){
    if(type=="i"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+2*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "sib"){
    if(type=="i"){
      probs <- 1/2*(3*MAFvec^2*(1-MAFvec )^2+2*(MAFvec*(1-MAFvec )^3)+2*MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 1/2*(5*MAFvec^2*(1-MAFvec )^2+4*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "pc"){
    if(type=="i"){
      probs <- 2*MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )
    }
    if(type=="i-ii"){
      probs <- 2*(2*MAFvec^2*(1-MAFvec )^2+ (MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
  }
  return(probs)
}

library(poibin)
library(cowplot)
set.seed(123)
pop.freq.full <- runif(80, 0.3, 0.5)
pop.freq.full45 <- runif(80, 0.40, 0.5)
pop.freq <- sort(pop.freq.full)[1:80]
(estimateMUDlow80 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="mud", type="i"), 3)))
(estimateSIBlow80 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="sib", type="i"), 3)))
pop.freq <- sort(pop.freq.full)[80:1]
(estimateMUDhigh80 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="mud", type="i"), 3)))
(estimateSIBhigh80 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="sib", type="i"), 3)))
pop.freq <- sort(pop.freq.full45)[1:80]
(estimateMUDlow80.45 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="mud", type="i"), 3)))
(estimateSIBlow80.45 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="sib", type="i"), 3)))
pop.freq <- sort(pop.freq.full45)[80:1]
(estimateMUDhigh80.45 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="mud", type="i"), 3)))
(estimateSIBhigh80.45 <- (sapply(1:length(pop.freq), cdfVec, MAFtoProb(pop.freq, donrec="sib", type="i"), 3)))



df <- data.frame(inf=c(estimateMUDlow80, estimateSIBlow80,
                       estimateMUDhigh80, estimateSIBhigh80),
                 type=c(rep("low", 160), rep("high", 160)),
                 nmark=rep(1:80, 4),
                 relatedness=rep(c(rep("unrelated",80), rep("sibling", 80)), 2))
d35 <- ggplot(df, aes(x=nmark, y=inf, color=type, linetype=relatedness,
                interaction(relatedness,type)))+
         geom_line()+
         theme_minimal()+
         xlab("Number of included markers")+
         ylab("Informativity rate")

df.45 <- data.frame(inf=c(estimateMUDlow80.45, estimateSIBlow80.45,
                          estimateMUDhigh80.45, estimateSIBhigh80.45),
                    type=c(rep("low", 160), rep("high", 160)),
                    nmark=rep(1:80, 4),
                    relatedness=rep(c(rep("unrelated",80), rep("sibling", 80)), 2))
d45 <- ggplot(df.45, aes(x=nmark, y=inf, color=type, linetype=relatedness,
                      interaction(relatedness,type)))+
  geom_line()+
  theme_minimal()+
  xlab("Number of included markers")+
  ylab("Informativity rate")
plot_grid(d35, d45, labels=c("a", "b"), nrow=2)


# range
min(which(estimateMUDlow80 > 0.99))
min(which(estimateMUDhigh80 > 0.99))
min(which(estimateMUDlow80.45 > 0.99))
min(which(estimateMUDhigh80.45 > 0.99))


#### replace one marker with two inferior MAF markers
maf.est <- rep(0.5, 24)
est.opt.mud <- sapply(length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 2)
est.opt.sib <- sapply(length(maf.est), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 2)
maf.est <- c(rep(0.5, 23), rep(0.49, 2))
est.subopt.mud <- sapply((length(maf.est)), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 2)
est.subopt.sib <- sapply((length(maf.est)), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 2)
count <- 2
while(est.opt.mud < est.subopt.mud && est.opt.sib < est.subopt.sib){
  maf.est <- c(rep(0.5, 23), rep(0.5-count*0.01, 2))
  est.subopt.mud <- sapply((length(maf.est)), cdfVec, MAFtoProb(maf.est, donrec="mud", type="i"), 2)
  est.subopt.sib <- sapply((length(maf.est)), cdfVec, MAFtoProb(maf.est, donrec="sib", type="i"), 2)
  count <- count + 1
}
lowest.maf <- 0.5-(count-2)*0.01
