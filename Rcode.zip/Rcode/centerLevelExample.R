library(poibin)

convertMAF <- function(MAF){
  return(min(MAF, 0.5)-max(MAF-0.5, 0))
}

MAFvec <- function(MAF, reps, n){
  rbinom(reps, n, MAF)/n
}

cdfVec <- function(use, probs, nmark){
  1-ppoibin(nmark, probs[1:use])
}

MAFtoProb <- function(MAFvec, donrec = c("sib", "mud", "pc"), type=c("i", "i-ii")){
  if(donrec == "mud"){
    if(type=="i"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 2*(MAFvec^2*(1-MAFvec )^2+2*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "sib"){
    if(type=="i"){
      probs <- 1/2*(3*MAFvec^2*(1-MAFvec )^2+2*(MAFvec*(1-MAFvec )^3)+2*MAFvec^3*(1-MAFvec ))
    }
    if(type=="i-ii"){
      probs <- 1/2*(5*MAFvec^2*(1-MAFvec )^2+4*((MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )))
    }
  }
  if(donrec == "pc"){
    if(type=="i"){
      probs <- 2*MAFvec^2*(1-MAFvec )^2+(MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec )
    }
    if(type=="i-ii"){
      probs <- 2*(2*MAFvec^2*(1-MAFvec )^2+ (MAFvec*(1-MAFvec )^3)+MAFvec^3*(1-MAFvec ))
    }
  }
  return(probs)
}
getCI <- function(maf.est, B, b, rel, type){
  d <- matrix(0, nrow = B, ncol = length(maf.est))
  for(iter in 1:B){
    d[iter,] <- sapply(1:length(maf.est), cdfVec, MAFtoProb(b[iter,], donrec=rel, type=type), 3)
  }
  quantiles <- c(0.025, 0.975)
  upper <- vector("numeric", length(maf.est))
  lower <- vector("numeric", length(maf.est))
  for(mark in 1:length(maf.est)){
    upper[mark] <- sort(d[, mark])[quantiles[2]*(B+1)]
    lower[mark] <- sort(d[, mark])[quantiles[1]*(B+1)]
  }
  return(list(upper=upper,lower=lower))
}


##################################
# example
##################################

# empirical MAFs
MAF1 <- c(0.4059633, 0.4357798, 0.3302752, 0.4128440, 0.4564220, 0.4839450, 0.3990826, 0.4403670, 0.4747706,
          0.3348624, 0.4311927, 0.4449541, 0.3922018, 0.3876147, 0.4128440, 0.3876147, 0.4380734, 0.4770642,
          0.4633028, 0.4885321, 0.4380734, 0.3394495, 0.4220183, 0.4380734)

# point estimates
(estimateMUD <- max(sapply(1:length(MAF1), cdfVec, MAFtoProb(MAF1, donrec="mud", type="i"), 3)))
(estimateSIB <- max(sapply(1:length(MAF1), cdfVec, MAFtoProb(MAF1, donrec="sib", type="i"), 3)))
(estimatePC <- max(sapply(1:length(MAF1), cdfVec, MAFtoProb(MAF1, donrec="pc", type="i"), 3)))
n <- 95+56+11
(estimateCenter <- estimateMUD*95/n + estimateSIB*56/n + estimatePC*11/n)

# limits
B=999
AF.dep <- 2*(95+56+11) # number of alleles used for MAF estimation
b <- matrix(MAFvec(MAF1, B*length(MAF1), AF.dep), nrow = B, byrow = TRUE)
MUDci <- c(getCI(MAF1, B = B, b=b, rel="mud", type="i")$lower[24],
           getCI(MAF1, B = B, b=b, rel="mud", type="i")$upper[24])
SIBci <- c(getCI(MAF1, B = B, b=b, rel="sib", type="i")$lower[24],
           getCI(MAF1, B = B, b=b, rel="sib", type="i")$upper[24])
PCci <- c(getCI(MAF1, B = B, b=b, rel="pc", type="i")$lower[24],
           getCI(MAF1, B = B, b=b, rel="pc", type="i")$upper[24])
(centerci <- c(MUDci[1]*95/n + SIBci[1]*56/n + PCci[1]*11/n,
               MUDci[2]*95/n + SIBci[2]*56/n + PCci[2]*11/n))
